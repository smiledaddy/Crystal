'''
register your third lib here use:
    import XXX as ArmoryXXX
'''
