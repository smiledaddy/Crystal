"""
    pylon web framework
    ~~~~~~~~~~~~~~~~~~~
"""

__version__ = '1.1.1-dev'
