from setuptools import setup, find_packages
setup(
    name='resource_console',
    version='1.0dev',
    packages=find_packages(),
    license='',
    long_description="",
    author='baina',
    author_email='admin@dolphin-browser.com',
    maintainer='Dolphin',
    url='http://www.dolphin-browser.com/'
)
