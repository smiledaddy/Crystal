#!/bin/bash
#
# This scripts is used to restart the application.
# This scripts is required for all projects.
#
#
# Author : chzhong
#

service resource_console_service restart
