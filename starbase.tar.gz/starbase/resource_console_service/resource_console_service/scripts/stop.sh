#!/bin/bash
#
# This scripts is used to stop the application.
#
#
# Author : kunli
#

service resource_console_service stop
