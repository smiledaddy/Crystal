#!/bin/bash
#
# This scripts is used to start the application.
#
#
# Author : chzhong
#

service auth_service start
