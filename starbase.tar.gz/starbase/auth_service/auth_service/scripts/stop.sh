#!/bin/bash
#
# This scripts is used to stop the application.
#
#
# Author : kunli
#

service auth_service stop
