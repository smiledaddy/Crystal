# -*- coding: utf-8 -*-
from pylon.frame import App, request, session


app = App(__name__)
app.secret_key = 'why would I tell you my secret key?'
