from setuptools import setup, find_packages
setup(
    name='auth_service',
    version='1.0dev',
    packages=find_packages(),
    license='',
    long_description=open('README.txt').read(),
    author='baina',
    author_email='yqliao@dolphin-browser.com',
    maintainer='Dolphin',
    url='http://www.dolphin-browser.com/'
)
