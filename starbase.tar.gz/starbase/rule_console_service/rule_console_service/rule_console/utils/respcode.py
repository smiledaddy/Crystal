# -*- coding: utf-8 -*-
"""
@author: zhhfang
@date: 2014-07-15
@description: The response code of API
"""


DATA_RELETED_BY_OTHER = 1004
DATA_DUPLICATE_DELETE = 1005
DUPLICATE_FIELD = 1006
BANNER_ERROR = 1007
PROMOTE_ERROR = 1008
