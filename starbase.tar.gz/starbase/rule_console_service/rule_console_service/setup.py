from setuptools import setup, find_packages
setup(
    name='rule_console',
    version='1.0dev',
    packages=find_packages(),
    license='',
    long_description=open('README.txt').read(),
    author='baina',
    author_email='admin@dolphin-browser.com',
    maintainer='Dolphin',
    url='http://www.dolphin-browser.com/'
)
